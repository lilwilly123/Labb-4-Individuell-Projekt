UPDATE Staff
SET 
    DepartmentId = 2,
    Salary = 35000,
    EmploymentDate = '2018-08-15'
WHERE Role = 'L�rare';
UPDATE Staff
SET 
    DepartmentId = 3,
    Salary = 45000,
    EmploymentDate = '2015-01-10'
WHERE Role = 'Rektor';
UPDATE Staff
SET 
    DepartmentId = 1,
    Salary = 32000,
    EmploymentDate = '2019-03-01'
WHERE Role = 'Administrat�r';
UPDATE Staff
SET 
    DepartmentId = 4,
    Salary = 33000,
    EmploymentDate = '2020-06-01'
WHERE Role = 'Kurator';
