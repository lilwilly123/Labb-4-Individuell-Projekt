SELECT 
    FirstName,
    LastName,
    Role,
    DATEDIFF(YEAR, EmploymentDate, GETDATE()) AS YearsWorked
FROM Staff;
