CREATE PROCEDURE GetStudentInfo
    @StudentId INT
AS
BEGIN
    SELECT 
        s.FirstName,
        s.LastName,
        c.Name AS Class,
        co.Name AS Course,
        g.GradeValue,
        g.GradeDate
    FROM Student s
    JOIN Class c ON s.ClassId = c.ClassId
    LEFT JOIN Grade g ON s.StudentId = g.StudentId
    LEFT JOIN Course co ON g.CourseId = co.CourseId
    WHERE s.StudentId = @StudentId;
END;
