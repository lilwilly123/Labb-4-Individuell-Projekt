CREATE TABLE Department (
    DepartmentId INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL
);
