SELECT 
    d.Name AS Department,
    SUM(s.Salary) AS TotalMonthlySalary
FROM Staff s
JOIN Department d ON s.DepartmentId = d.DepartmentId
GROUP BY d.Name;
