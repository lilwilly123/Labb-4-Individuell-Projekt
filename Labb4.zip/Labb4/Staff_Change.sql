ALTER TABLE Staff
ADD DepartmentId INT,
    Salary INT,
    EmploymentDate DATE;

ALTER TABLE Staff
ALTER COLUMN Salary INT NOT NULL;

ALTER TABLE Staff
ALTER COLUMN EmploymentDate DATE NOT NULL;

ALTER TABLE Staff
ADD CONSTRAINT FK_Staff_Department
FOREIGN KEY (DepartmentId) REFERENCES Department(DepartmentId);