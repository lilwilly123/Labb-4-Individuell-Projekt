INSERT INTO Department (Name)
VALUES 
('IT'),
('L�rare'),
('Administration'),
('Elevh�lsa');
