SELECT 
    d.Name AS Department,
    AVG(s.Salary) AS AverageSalary
FROM Staff s
JOIN Department d ON s.DepartmentId = d.DepartmentId
GROUP BY d.Name;
